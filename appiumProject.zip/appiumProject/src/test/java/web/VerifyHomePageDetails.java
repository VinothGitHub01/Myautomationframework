package web;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import base.BaseTest;
import io.qameta.allure.Allure;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.testng.Tag;
import pages.web.HomePage;
import utils.Utilities;

public class VerifyHomePageDetails extends BaseTest {

	WebDriver driver;
	String url = "https://ultimateqa.com/";
	String browser = "chrome";
	HomePage homePage;
	ExtentTest verifyHomePageDetailsExtentTest;
	String driverString;
	LinkedHashMap<String, String> testCases = new LinkedHashMap<>();
	Boolean webDriverLocal = false;

	@BeforeClass
	public void beforeClassSetup() throws Exception {
		try {
			log.info("====================" + getClass().getName() + " execution started" + "===================");
		} catch (Throwable t) {
			log.error(t.toString(), t);
			verifyHomePageDetailsExtentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}

	}

	@BeforeMethod
	public void setUp() throws InterruptedException {
		log.info("====================" + getClass().getName() + " test started" + "===================");
		verifyHomePageDetailsExtentTest = extentReports.createTest("Web - To verify home page details");

		driver = iniaiteWebDriver(browser);
		driverString = driver.toString();
		log.info(driver + " started successfully");
		Allure.step(driver + " started successfully");
		verifyHomePageDetailsExtentTest.log(Status.INFO, "Launched " + "<b>" + browser + "</b>" + " browser");
		log.info("Launched " + "<b>" + browser + "</b>" + " browser");
		Allure.step("Launched " + "<b>" + browser + "</b>" + " browser");
		web_OpenURL(url);
		verifyHomePageDetailsExtentTest.log(Status.INFO, "Navigated to: " + url);
		log.info("Navigated to: " + url);
		Allure.step("Navigated to: " + url);

		// Object Creation
		homePage = new HomePage(driver);
		log.info(homePage + " - Object created successfully");

		// Test Case
		testCases = new LinkedHashMap<>();
	}

	@Epic("Web - Verify Home Page Details - Epic")
	@Feature("Web - Verify Home Page Details - Feature")
	@Story("Web - Verify Home Page Details - Story")
	@Tag("Regression")
	@Severity(SeverityLevel.NORMAL)
	@Step
	@Parameters("TestCases")
	@Test
	public void verifyHomePageDetails(Method m, @Optional("Optional Parameter") String testCase) throws Exception {
		verifyHomePageDetailsExtentTest.assignCategory("Regression");
		if (webDriverLocal) {
			String localTestCase = "TC01-TC03";
			testCases = Utilities.testCaseParser(localTestCase);
		} else {
			testCases = Utilities.testCaseParser(testCase);
		}
		log.info(m.getName() + " - test cases to be executed: " + testCases);
		testCaseContainer(testCases);
	}

	public void testCaseContainer(LinkedHashMap<String, String> testCases) throws Exception {
		try {
			if (testCases.containsKey("TC01")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC01"));
			}
			if (testCases.containsKey("TC02")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC02"));
			}
			if (testCases.containsKey("TC03")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC03"));
			}
			if (testCases.containsKey("TC04")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC04"));
			}
			if (testCases.containsKey("TC05")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC05"));
			}
			if (testCases.containsKey("TC06")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC06"));
			}
			if (testCases.containsKey("TC07")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC07"));
			}
			if (testCases.containsKey("TC08")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC08"));
			}
			if (testCases.containsKey("TC09")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC09"));
			}
			if (testCases.containsKey("TC10")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC10"));
			}
			if (testCases.containsKey("TC11")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC11"));
			}
			if (testCases.containsKey("TC12")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC12"));
			}
			if (testCases.containsKey("TC13")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC13"));
			}
			if (testCases.containsKey("TC14")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC14"));
			}
			if (testCases.containsKey("TC15")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC15"));
			}
			if (testCases.containsKey("TC16")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC10"));
			}
			if (testCases.containsKey("TC17")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC16"));
			}
			if (testCases.containsKey("TC18")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC18"));
			}
			if (testCases.containsKey("TC19")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC19"));
			}
			if (testCases.containsKey("TC20")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC20"));
			}
			if (testCases.containsKey("TC21")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC21"));
			}
			if (testCases.containsKey("TC22")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC22"));
			}
			if (testCases.containsKey("TC23")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC23"));
			}
			if (testCases.containsKey("TC24")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC24"));
			}
			if (testCases.containsKey("TC25")) {
				verifyUltiMateQAIMGIsExists(testCases.get("TC25"));
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			verifyHomePageDetailsExtentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	public void verifyUltiMateQAIMGIsExists(String testCase) throws Exception {
		try {
			Allure.description("Web - Verify UltiMateQAIMG Is Exists");
			String testCaseDetails = "<b>" + "==================== " + testCase + " - UltiMateQAIMG"
					+ " ====================" + "</b>";
			log.info(testCaseDetails);
			verifyHomePageDetailsExtentTest.info(testCaseDetails);
			Allure.step(testCaseDetails);
			Thread.sleep(10);
			boolean ultiMateQAIMGIsExists = homePage.ultiMateQAIMGIsExit();
			log.info("ultiMateQAIMGIsExists: " + ultiMateQAIMGIsExists);
			Allure.step("ultiMateQAIMGIsExists: " + ultiMateQAIMGIsExists);
			if (ultiMateQAIMGIsExists) {
				verifyHomePageDetailsExtentTest.pass("ultiMateQAIMG is exist");
			} else {
				verifyHomePageDetailsExtentTest.fail("ultiMateQAIMG is not exist");
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			verifyHomePageDetailsExtentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	@AfterMethod
	public void tearDown(Method m) throws Exception {
		log.info(m.getName() + " After method");
		try {
			if (driver != null) {
				driver.quit();
				verifyHomePageDetailsExtentTest.info("Driver quit");
				log.info(driverString + " quits successfully");
				Allure.step(driverString + " quits successfully");
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			verifyHomePageDetailsExtentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}
		log.info("====================" + m.getName() + " test ended" + "===================");
		Thread.sleep(4);
	}

	@AfterClass
	public void afterClassSetup() throws Exception {
		log.info("====================" + getClass().getName() + " execution ended" + "===================");
	}

}
