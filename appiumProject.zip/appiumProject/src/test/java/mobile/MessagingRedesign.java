package mobile;

import java.lang.reflect.Method;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedHashMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.BaseTest;
import io.appium.java_client.AppiumDriver;
import io.qameta.allure.Allure;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.testng.Tag;
import pages.Messaging;
import utils.Utilities;

public class MessagingRedesign extends BaseTest {

	URL url;
	Messaging messaging;
	boolean appiumLocal = false;
	String appiumLocalPort = "4723";
	LinkedHashMap<String, String> testCases = new LinkedHashMap<>();
	LinkedHashMap<String, String> desiredCapMap;
//	AppiumDriver<WebElement> driver;
	DesiredCapabilities dc;
	String driverString;

	@BeforeClass
	public void beforeClassSetup() throws Exception {
		try {
			log.info("====================" + getClass().getName() + " execution started" + "===================");
			desiredCapMap = new LinkedHashMap<>();

			String ipAddress = Utilities.getIPAddress();
			if (appiumLocal) {
				url = new URL("http://127.0.1:" + appiumLocalPort + "/wd/hub");
				desiredCapMap.put("platformName", "Android");
				desiredCapMap.put("automationName", "UiAutomator2");
				desiredCapMap.put("appPackage", "com.google.android.apps.messaging");
				desiredCapMap.put("appActivity", "com.google.android.apps.messaging.ui.ConversationListActivity");
				desiredCapMap.put("deviceName", "emulator-5554");
			} else {
				url = new URL("http://" + ipAddress + ":4444/wd/hub");
				desiredCapMap.put("platformName", "Android");
				desiredCapMap.put("automationName", "UiAutomator2");
				desiredCapMap.put("appPackage", "com.google.android.apps.messaging");
				desiredCapMap.put("appActivity", "com.google.android.apps.messaging.ui.ConversationListActivity");
				desiredCapMap.put("udid", "emulator-5556");
				desiredCapMap.put("deviceName", "emulator-5556");
				desiredCapMap.put("systemPort", "8202");
			}

			dc = new DesiredCapabilities(desiredCapMap);

		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}
	}

	@BeforeMethod()
	public void setup(Method m) throws Exception {
		try {
			log.info("====================" + m.getName() + " test started" + "===================");
			extentTest = extentReports.createTest(
					"Mobile - " + getClass().getSimpleName() + " " + m.getName() + " Test",
					getClass().getSimpleName() + " " + m.getName() + " Test");
			extentTest.info("<b>" + "Appium server url: " + url + "</b>");
			log.info("<b>" + "Appium server url: " + url + "</b>");
			extentTest.info("<b>" + "Desired Capability: " + desiredCapMap.toString() + "</b>");
			log.info("<b>" + "Desired Capability: " + desiredCapMap.toString() + "</b>");

			AppiumDriver<WebElement> driver = setUpDriver("Android", url, dc);
			log.info(driver + " started successfully");
			driverString = driver.toString();
			// Object Creation
			messaging = new Messaging(driver);
			log.info(messaging + " - Object created successfully");

			// Test Case
			testCases = new LinkedHashMap<>();

		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}
	}

//	@Epic("Message - Epic")
//	@Feature("Message test - Feature")
//	@Story("Message - Story")
//	@Tag("Smoke")
//	@Severity(SeverityLevel.BLOCKER)
//	@Step
//	@Test(invocationCount = 1, groups = { "Smoke" })
//	public void sendMessageTest(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}
//
//	@Epic("Message - Epic")
//	@Feature("Message test - Feature")
//	@Story("Message - Story")
//	@Tag("Sanity")
//	@Severity(SeverityLevel.CRITICAL)
//	@Step
//	@Test(invocationCount = 1, groups = { "Sanity" })
//	public void sendMessageTest2(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		testCases.put("TC02", "TC02");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}

//	@Epic("Message3 - Epic")
//	@Feature("Message test3 - Feature")
//	@Story("Message3 - Story")
//	@Tag("Regression")
//	@Severity(SeverityLevel.MINOR)
//	@Step
//	@Test(invocationCount = 1, groups = { "Regression" })
//	public void sendMessageTest3(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		testCases.put("TC02", "TC02");
//		testCases.put("TC03", "TC03");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}
//
//	@Epic("Message4 - Epic")
//	@Feature("Message test4 - Feature")
//	@Story("Message4 - Story")
//	@Tag("SmokeSanity")
//	@Severity(SeverityLevel.NORMAL)
//	@Step
//	@Test(invocationCount = 1, groups = { "Smoke", "Sanity" })
//	public void sendMessageTest4(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		testCases.put("TC02", "TC02");
//		testCases.put("TC03", "TC03");
//		testCases.put("TC04", "TC04");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}

	@Epic("Mobile - Message5 - Epic")
	@Feature("Mobile - Message test5 - Feature")
	@Story("Mobile - Message5 - Story")
	@Tag("Regression")
	@Severity(SeverityLevel.NORMAL)
	@Step
	@Parameters("TestCases")
	@Test(invocationCount = 1)
	public void sendMessageTest5(Method m, @Optional("Optional Parameter") String testCase) throws Exception {
		extentTest.assignCategory("Regression");
		if (appiumLocal) {
			String localTestCase = "TC01-TC02";
			testCases = Utilities.testCaseParser(localTestCase);
		} else {
			testCases = Utilities.testCaseParser(testCase);
		}
		log.info(m.getName() + " - test cases to be executed: " + testCases);
		testCaseContainer(testCases);
	}

	public void testCaseContainer(LinkedHashMap<String, String> testCases) throws Exception {
		try {
			if (testCases.containsKey("TC01")) {
				sendMessageTestHelper1(testCases.get("TC01"));
			}
			if (testCases.containsKey("TC02")) {
				sendMessageTestHelper2(testCases.get("TC02"));
			}
			if (testCases.containsKey("TC03")) {
				sendMessageTestHelper2(testCases.get("TC03"));
			}
			if (testCases.containsKey("TC04")) {
				sendMessageTestHelper2(testCases.get("TC04"));
			}
			if (testCases.containsKey("TC05")) {
				sendMessageTestHelper2(testCases.get("TC05"));
			}
			if (testCases.containsKey("TC06")) {
				sendMessageTestHelper2(testCases.get("TC06"));
			}
			if (testCases.containsKey("TC07")) {
				sendMessageTestHelper2(testCases.get("TC07"));
			}
			if (testCases.containsKey("TC08")) {
				sendMessageTestHelper2(testCases.get("TC08"));
			}
			if (testCases.containsKey("TC09")) {
				sendMessageTestHelper2(testCases.get("TC09"));
			}
			if (testCases.containsKey("TC10")) {
				sendMessageTestHelper2(testCases.get("TC10"));
			}
			if (testCases.containsKey("TC11")) {
				sendMessageTestHelper2(testCases.get("TC11"));
			}
			if (testCases.containsKey("TC12")) {
				sendMessageTestHelper2(testCases.get("TC12"));
			}
			if (testCases.containsKey("TC13")) {
				sendMessageTestHelper2(testCases.get("TC13"));
			}
			if (testCases.containsKey("TC14")) {
				sendMessageTestHelper2(testCases.get("TC14"));
			}
			if (testCases.containsKey("TC15")) {
				sendMessageTestHelper2(testCases.get("TC15"));
			}
			if (testCases.containsKey("TC16")) {
				sendMessageTestHelper2(testCases.get("TC16"));
			}
			if (testCases.containsKey("TC17")) {
				sendMessageTestHelper2(testCases.get("TC17"));
			}
			if (testCases.containsKey("TC18")) {
				sendMessageTestHelper2(testCases.get("TC18"));
			}
			if (testCases.containsKey("TC19")) {
				sendMessageTestHelper2(testCases.get("TC19"));
			}
			if (testCases.containsKey("TC20")) {
				sendMessageTestHelper2(testCases.get("TC20"));
			}
			if (testCases.containsKey("TC21")) {
				sendMessageTestHelper2(testCases.get("TC21"));
			}
			if (testCases.containsKey("TC22")) {
				sendMessageTestHelper2(testCases.get("TC22"));
			}
			if (testCases.containsKey("TC23")) {
				sendMessageTestHelper2(testCases.get("TC23"));
			}
			if (testCases.containsKey("TC24")) {
				sendMessageTestHelper2(testCases.get("TC24"));
			}
			if (testCases.containsKey("TC25")) {
				sendMessageTestHelper2(testCases.get("TC25"));
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	public void sendMessageTestHelper1(String testCase) throws Exception {
		try {
			Allure.description("Mobile - Send text");
			String testCaseDetails = "<b>" + "------------------------------------ " + testCase + " - Send text"
					+ " ------------------------------------" + "</b>";
			log.info(testCaseDetails);
			extentTest.info(testCaseDetails);
			Allure.step(testCaseDetails);
			messaging.clickStartChatTab();
			messaging.clickStartChatTab();
			extentTest.info("Clicked on Start chat button");
			Allure.step("Clicked on Start chat button");
			String recipientText = "Gilb";
			messaging.sendRecipientText(recipientText);
			extentTest.info("Search text - " + recipientText);
			log.info("Search text - " + recipientText);
			Allure.step("Search text - " + recipientText);
			if (messaging.recipientTextViewIsDisplayed()) {
				String contacName = messaging.getContactName();
				extentTest.info("Contact Name: " + contacName);
				log.info("Contact Name: " + contacName);
				Allure.step("Contact Name: " + contacName);
				messaging.clickContactName();
				extentTest.info("Clicked on contact name text");
				log.info("Clicked on contact name text");
				Allure.step("Clicked on contact name text");
				Thread.sleep(50);
				String composeMessageText = "Hi Gilbert, we can go at 5 clock";
				messaging.sendcomposeMessageText(composeMessageText);
				extentTest.info("Sending text - " + composeMessageText);
				log.info("Sending text - " + composeMessageText);
				Allure.step("Sending text - " + composeMessageText);
				messaging.clickSendMessageButton();
				extentTest.info("Clicked send message button");
				log.info("Clicked send message button");
				Allure.step("Clicked send message button");
				Thread.sleep(30);
				if (messaging.messageStatusIsDisplayed()) {
					extentTest.pass("Your message sent successfuly",
							MediaEntityBuilder.createScreenCaptureFromPath(messaging.getScreenshotPath("No")).build());
					Allure.addAttachment("Send text",
							Files.newInputStream(Paths.get(messaging.getScreenshotPath("No"))));
					Allure.step("Test Passed", io.qameta.allure.model.Status.PASSED);

				} else {
					extentTest.fail("Your message not sent",
							MediaEntityBuilder.createScreenCaptureFromPath(messaging.getScreenshotPath("No")).build());
					Allure.addAttachment("Send text",
							Files.newInputStream(Paths.get(messaging.getScreenshotPath("No"))));
					Allure.step("Test Failed", io.qameta.allure.model.Status.FAILED);
				}
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	public void sendMessageTestHelper2(String testCase) throws Exception {
		try {
			Allure.description("Send text");
			String testCaseDetails = "<b>" + "==================== " + testCase + " - Dial a number"
					+ " ====================" + "</b>";
			log.info(testCaseDetails);
			extentTest.info(testCaseDetails);
			Allure.step(testCaseDetails);
			Thread.sleep(5);
			String composeMessageText = "Hi Gilbert, we can go at 5 clock";
			messaging.sendcomposeMessageText(composeMessageText);
			extentTest.info("Sending text - " + composeMessageText);
			log.info("Sending text - " + composeMessageText);
			Allure.step("Sending text - " + composeMessageText);
			messaging.clickSendMessageButton();
			extentTest.info("Clicked send message button");
			log.info("Clicked send message button");
			Allure.step("Clicked send message button");
			Thread.sleep(30);
			if (messaging.messageStatusIsDisplayed()) {
				extentTest.pass("Your message sent successfuly",
						MediaEntityBuilder.createScreenCaptureFromPath(messaging.getScreenshotPath("No")).build());
				Allure.addAttachment("Send text", Files.newInputStream(Paths.get(messaging.getScreenshotPath("No"))));
				Allure.step("Test Passed", io.qameta.allure.model.Status.PASSED);

			} else {
				extentTest.fail("Your message not sent",
						MediaEntityBuilder.createScreenCaptureFromPath(messaging.getScreenshotPath("No")).build());
				Allure.addAttachment("Send text", Files.newInputStream(Paths.get(messaging.getScreenshotPath("No"))));
				Allure.step("Test Failed", io.qameta.allure.model.Status.FAILED);
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	@AfterMethod
	public void tearDown(Method m) throws Exception {
		log.info(m.getName() + " After method");
		try {
			if (driver != null) {
				driver.quit();
				extentTest.info("Driver quit");
				log.info(m.getName() + ": Driver: " + driverString + " quits successfully");
				Allure.step(m.getName() + ": Driver: " + driverString + " quits successfully");
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}
		log.info("====================" + m.getName() + " test ended" + "===================");
		Thread.sleep(4);
	}

	@AfterClass
	public void afterClassSetup() throws Exception {
		log.info("====================" + getClass().getName() + " execution ended" + "===================");
	}

}
