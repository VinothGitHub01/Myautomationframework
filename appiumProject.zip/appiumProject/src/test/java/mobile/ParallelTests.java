package mobile;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import base.BaseTest;
import io.appium.java_client.AppiumDriver;

public class ParallelTests extends BaseTest {

	@Test
	public void test1() throws MalformedURLException, InterruptedException {
		System.out.println("test1 started");
		DesiredCapabilities dc1 = new DesiredCapabilities();
		dc1.setCapability("platformName", "Android");
		dc1.setCapability("automationName", "UiAutomator2");
		dc1.setCapability("appPackage", "com.google.android.dialer");
		dc1.setCapability("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
		dc1.setCapability("udid", "emulator-5554");
		dc1.setCapability("deviceName", "emulator-5554");
		dc1.setCapability("systemPort", "8201");

		URL url = new URL("http://192.168.27.115:4444/wd/hub");

		RemoteWebDriver driv = new RemoteWebDriver(url, dc1);

		driv.findElementById("com.google.android.dialer:id/dialpad_fab").click();
		Thread.sleep(1);
		driv.quit();
		System.out.println("test1 ended");
	}

	@Test
	public void test2() throws MalformedURLException, InterruptedException {
		System.out.println("test2 started");
		DesiredCapabilities dc1 = new DesiredCapabilities();
		dc1.setCapability("platformName", "Android");
		dc1.setCapability("automationName", "UiAutomator2");
		dc1.setCapability("appPackage", "com.google.android.dialer");
		dc1.setCapability("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
		dc1.setCapability("udid", "emulator-5556");
		dc1.setCapability("deviceName", "emulator-5556");
		dc1.setCapability("systemPort", "8202");

		URL url = new URL("http://192.168.27.115:4444/wd/hub");

		RemoteWebDriver driv = new RemoteWebDriver(url, dc1);

		driv.findElementById("com.google.android.dialer:id/dialpad_fab").click();
		Thread.sleep(1);
		driv.quit();
		System.out.println("test2 ended");
	}

	@Test
	public void test3() throws MalformedURLException, InterruptedException {
		System.out.println("test3 started");
		DesiredCapabilities dc1 = new DesiredCapabilities();
		dc1.setCapability("platformName", "Android");
		dc1.setCapability("automationName", "UiAutomator2");
		dc1.setCapability("appPackage", "com.google.android.dialer");
		dc1.setCapability("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
		dc1.setCapability("udid", "emulator-5554");
		dc1.setCapability("deviceName", "emulator-5554");
		dc1.setCapability("systemPort", "8201");

		URL url = new URL("http://192.168.27.115:4444/wd/hub");

		AppiumDriver<WebElement> driv = new AppiumDriver(url, dc1);

		driv.findElementById("com.google.android.dialer:id/dialpad_fab").click();
		Thread.sleep(1);
		driv.quit();
		System.out.println("test3 ended");
	}

	@Test
	public void test4() throws MalformedURLException, InterruptedException {
		System.out.println("test4 started");
		DesiredCapabilities dc1 = new DesiredCapabilities();
		dc1.setCapability("platformName", "Android");
		dc1.setCapability("automationName", "UiAutomator2");
		dc1.setCapability("appPackage", "com.google.android.dialer");
		dc1.setCapability("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
		dc1.setCapability("udid", "emulator-5556");
		dc1.setCapability("deviceName", "emulator-5556");
		dc1.setCapability("systemPort", "8202");

		URL url = new URL("http://192.168.27.115:4444/wd/hub");

		AppiumDriver<WebElement> driv = new AppiumDriver(url, dc1);

		driv.findElementById("com.google.android.dialer:id/dialpad_fab").click();
		Thread.sleep(1);
		driv.quit();
		System.out.println("test4 ended");
	}

}
