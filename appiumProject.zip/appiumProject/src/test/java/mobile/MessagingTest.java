package mobile;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;

public class MessagingTest {

	DesiredCapabilities dc;
	URL url;
	AppiumDriver<WebElement> driver;
	WebDriverWait wait;

	@BeforeClass
	public void setup() {
		dc = new DesiredCapabilities();
		dc.setCapability("automationName", "appium");
		dc.setCapability("platformName", "android");
		dc.setCapability("platformVersion", "13");
		dc.setCapability("deviceName", "emulator-5554");

		dc.setCapability("appPackage", "com.google.android.apps.messaging");
		dc.setCapability("appActivity", "com.google.android.apps.messaging.ui.ConversationListActivity");

		try {
			url = new URL("http://127.0.1:4723/wd/hub");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		driver = new AppiumDriver<WebElement>(url, dc);
		wait = new WebDriverWait(driver, 30);
	}

	@Test(priority = 0, enabled = false)
	public void verifyWelcomeText() {
//		String actualWelcomeText = driver.findElementById("com.google.android.apps.messaging:id/empty_text_hint")
//				.getText();
		String actualWelcomeText = wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.id("com.google.android.apps.messaging:id/empty_text_hint")))
				.getText();
		String expectedWelcomeText = "Once you start a new conversation, you’ll see it listed here";
		if (actualWelcomeText.equals(expectedWelcomeText)) {
			System.out.println("Correct Welcome Text");
		} else {
			System.out.println("Incorrect Welcome Text");
		}
	}

	@Test(priority = 1, invocationCount = 5)
	public void sendText() throws InterruptedException {
		driver.findElementById("com.google.android.apps.messaging:id/start_chat_fab").click();
		driver.findElementById("com.google.android.apps.messaging:id/start_chat_fab").click();
		Thread.sleep(15);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.id("com.google.android.apps.messaging:id/recipient_text_view")))
				.sendKeys("Gilb");
//		driver.findElementById("com.google.android.apps.messaging:id/recipient_text_view").sendKeys("Gilb");
		// com.google.android.apps.messaging:id/contact_details

		if (wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.id("com.google.android.apps.messaging:id/recipient_text_view")))
				.isDisplayed()) {
			System.out.println("Full name: "
					+ driver.findElement(By.id("com.google.android.apps.messaging:id/contact_name")).getText());
			driver.findElementById("com.google.android.apps.messaging:id/contact_name").click();
			Thread.sleep(40);
			// com.google.android.apps.messaging:id/compose_message_text
			driver.findElementById("com.google.android.apps.messaging:id/compose_message_text")
					.sendKeys("Hi Gilbert, we can go at 5 clock");
			Thread.sleep(10);
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.id("com.google.android.apps.messaging:id/send_message_button_icon")))
					.click();
			Thread.sleep(25);
			System.out.println("Your message sent successfuly");
		}

	}

	@AfterMethod
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
