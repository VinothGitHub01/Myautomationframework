package mobile;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class DialNumberTest {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		DesiredCapabilities dc = new DesiredCapabilities();

		dc.setCapability("automationName", "Appium");
		dc.setCapability("platformName", "Android");
		dc.setCapability("platformVersion", "13");
		dc.setCapability("deviceName", "emulator-5554");

		dc.setCapability("appPackage", "com.google.android.dialer");
		dc.setCapability("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");

		URL url = new URL("http://127.0.1:4723/wd/hub");

		AndroidDriver<WebElement> driver = new AndroidDriver<WebElement>(url, dc);

		driver.findElementById("com.google.android.dialer:id/dialpad_fab").click();

		Thread.sleep(20);

//		driver.findElementById("com.google.android.dialer:id/five").click();

		Map<Integer, String> numberMap = new HashMap<>();

		numberMap.put(0, "zero");
		numberMap.put(1, "one");
		numberMap.put(2, "two");
		numberMap.put(3, "three");
		numberMap.put(4, "four");
		numberMap.put(5, "five");
		numberMap.put(6, "six");
		numberMap.put(7, "seven");
		numberMap.put(8, "eight");
		numberMap.put(9, "nine");

		WebDriverWait wait = new WebDriverWait(driver, 50);

		String number = "539179165391791653917916";

		for (int i = 0; i < number.length(); i++) {
			int num = Integer.valueOf(String.valueOf(number.charAt(i)));
			System.out.println("num: " + num);
			System.out.println("numberMap.get(num): " + numberMap.get(num));
//			driver.findElementById("com.google.android.dialer:id/" + numberMap.get(num)).click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.id("com.google.android.dialer:id/" + numberMap.get(num)))).click();

		}

		driver.findElementById("com.google.android.dialer:id/dialpad_voice_call_button").click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.google.android.dialer:id/incall_end_call")))
				.click();
		
		driver.quit();

	}

}
