package mobile;

import java.lang.reflect.Method;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.BaseTest;
import io.appium.java_client.AppiumDriver;
import io.qameta.allure.Allure;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.testng.Tag;
import pages.DialNumber;
import utils.Utilities;

public class DialNumberRedesign extends BaseTest {

	URL url;
	DialNumber dialNumber;
	boolean appiumLocal = false;
	String appiumLocalPort = "4723";
	LinkedHashMap<String, String> testCases = new LinkedHashMap<>();
	LinkedHashMap<String, String> desiredCapMap;
//	AppiumDriver<WebElement> driver;
	DesiredCapabilities dc;
	String driverString;

	@BeforeClass
	public void beforeClassSetup() throws Exception {
		try {
			log.info("====================" + getClass().getName() + " execution started" + "===================");
			desiredCapMap = new LinkedHashMap<>();
			String ipAddress = Utilities.getIPAddress();
			if (appiumLocal) {
				url = new URL("http://127.0.1:" + appiumLocalPort + "/wd/hub");
				desiredCapMap.put("platformName", "Android");
				desiredCapMap.put("automationName", "UiAutomator2");
				desiredCapMap.put("appPackage", "com.google.android.dialer");
				desiredCapMap.put("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
				desiredCapMap.put("deviceName", "emulator-5554");
			} else {
				url = new URL("http://" + ipAddress + ":4444/wd/hub");
				desiredCapMap.put("platformName", "Android");
				desiredCapMap.put("automationName", "UiAutomator2");
				desiredCapMap.put("appPackage", "com.google.android.dialer");
				desiredCapMap.put("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
				desiredCapMap.put("udid", "emulator-5554");
				desiredCapMap.put("deviceName", "emulator-5554");
				desiredCapMap.put("systemPort", "8201");
			}

			dc = new DesiredCapabilities(desiredCapMap);

		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}

	}

	@BeforeMethod()
	public void setup(Method m) throws Exception {
		try {
			log.info("====================" + m.getName() + " test started" + "===================");
			extentTest = extentReports.createTest(
					"Mobile - " + getClass().getSimpleName() + " " + m.getName() + " Test",
					getClass().getSimpleName() + " " + m.getName() + " Test");
			extentTest.info("<b>" + "Appium server url: " + url + "</b>");
			log.info("<b>" + "Appium server url: " + url + "</b>");
			extentTest.info("<b>" + "Desired Capability: " + desiredCapMap.toString() + "</b>");
			log.info("<b>" + "Desired Capability: " + desiredCapMap.toString() + "</b>");

			AppiumDriver<WebElement> driver = setUpDriver("Android", url, dc);
			log.info(driver + " started successfully");
			driverString = driver.toString();
			// Object Creation
			dialNumber = new DialNumber(driver);
			log.info(dialNumber + " - Object created successfully");

			// Test Case
			testCases = new LinkedHashMap<>();

		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}
	}

//	@Epic("Dialpad - Epic")
//	@Feature("Dialpad test - Feature")
//	@Story("Dial Number - Story")
//	@Tag("Smoke")
//	@Severity(SeverityLevel.BLOCKER)
//	@Step
//	@Test(invocationCount = 1, groups = { "Smoke" })
//	public void dialPadTest(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}
//
//	@Epic("Dialpad2 - Epic")
//	@Feature("Dialpad test2 - Feature")
//	@Story("Dial Number2 - Story")
//	@Tag("Sanity")
//	@Severity(SeverityLevel.CRITICAL)
//	@Step
//	@Test(invocationCount = 1, groups = { "Sanity" })
//	public void dialPadTest2(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		testCases.put("TC02", "TC02");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}

//	@Epic("Dialpad3 - Epic")
//	@Feature("Dialpad test3 - Feature")
//	@Story("Dial Number3 - Story")
//	@Tag("Regression")
//	@Severity(SeverityLevel.MINOR)
//	@Step
//	@Test(invocationCount = 1, groups = { "Regression" })
//	public void dialPadTest3(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		testCases.put("TC02", "TC02");
//		testCases.put("TC03", "TC03");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}
//
//	@Epic("Dialpad4 - Epic")
//	@Feature("Dialpad test4 - Feature")
//	@Story("Dial Number4 - Story")
//	@Tag("SmokeSanity")
//	@Severity(SeverityLevel.NORMAL)
//	@Step
//	@Test(invocationCount = 1, groups = { "Smoke", "Sanity" })
//	public void dialPadTest4(Method m) throws Exception {
//		testCases.put("TC01", "TC01");
//		testCases.put("TC02", "TC02");
//		testCases.put("TC03", "TC03");
//		testCases.put("TC04", "TC04");
//		log.info(m.getName() + " - test cases to be executed: " + testCases);
//		testCaseContainer(testCases);
//	}

	@Epic("Mobile - Dialpad5 - Epic")
	@Feature("Mobile - Dialpad test5 - Feature")
	@Story("Mobile - Dial Number5 - Story")
	@Tag("Regression")
	@Severity(SeverityLevel.NORMAL)
	@Step
	@Parameters("TestCases")
	@Test(invocationCount = 1)
	public void dialPadTest5(Method m, @Optional("Optional Parameter") String testCase) throws Exception {
		extentTest.assignCategory("Regression");
		if (appiumLocal) {
			String localTestCase = "TC01-TC02";
			testCases = Utilities.testCaseParser(localTestCase);
		} else {
			testCases = Utilities.testCaseParser(testCase);
		}
		log.info(m.getName() + " - test cases to be executed: " + testCases);
		testCaseContainer(testCases);
	}

	public void testCaseContainer(LinkedHashMap<String, String> testCases) throws Exception {
		try {
			if (testCases.containsKey("TC01")) {
				dialPadTestHelper(testCases.get("TC01"));
			}
			if (testCases.containsKey("TC02")) {
				dialPadTestHelper(testCases.get("TC02"));
			}
			if (testCases.containsKey("TC03")) {
				dialPadTestHelper(testCases.get("TC03"));
			}
			if (testCases.containsKey("TC04")) {
				dialPadTestHelper(testCases.get("TC04"));
			}
			if (testCases.containsKey("TC05")) {
				dialPadTestHelper(testCases.get("TC05"));
			}
			if (testCases.containsKey("TC06")) {
				dialPadTestHelper(testCases.get("TC06"));
			}
			if (testCases.containsKey("TC07")) {
				dialPadTestHelper(testCases.get("TC07"));
			}
			if (testCases.containsKey("TC08")) {
				dialPadTestHelper(testCases.get("TC08"));
			}
			if (testCases.containsKey("TC09")) {
				dialPadTestHelper(testCases.get("TC09"));
			}
			if (testCases.containsKey("TC10")) {
				dialPadTestHelper(testCases.get("TC10"));
			}
			if (testCases.containsKey("TC11")) {
				dialPadTestHelper(testCases.get("TC11"));
			}
			if (testCases.containsKey("TC12")) {
				dialPadTestHelper(testCases.get("TC12"));
			}
			if (testCases.containsKey("TC13")) {
				dialPadTestHelper(testCases.get("TC13"));
			}
			if (testCases.containsKey("TC14")) {
				dialPadTestHelper(testCases.get("TC14"));
			}
			if (testCases.containsKey("TC15")) {
				dialPadTestHelper(testCases.get("TC15"));
			}
			if (testCases.containsKey("TC16")) {
				dialPadTestHelper(testCases.get("TC10"));
			}
			if (testCases.containsKey("TC17")) {
				dialPadTestHelper(testCases.get("TC16"));
			}
			if (testCases.containsKey("TC18")) {
				dialPadTestHelper(testCases.get("TC18"));
			}
			if (testCases.containsKey("TC19")) {
				dialPadTestHelper(testCases.get("TC19"));
			}
			if (testCases.containsKey("TC20")) {
				dialPadTestHelper(testCases.get("TC20"));
			}
			if (testCases.containsKey("TC21")) {
				dialPadTestHelper(testCases.get("TC21"));
			}
			if (testCases.containsKey("TC22")) {
				dialPadTestHelper(testCases.get("TC22"));
			}
			if (testCases.containsKey("TC23")) {
				dialPadTestHelper(testCases.get("TC23"));
			}
			if (testCases.containsKey("TC24")) {
				dialPadTestHelper(testCases.get("TC24"));
			}
			if (testCases.containsKey("TC25")) {
				dialPadTestHelper(testCases.get("TC25"));
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	public void dialPadTestHelper(String testCase) throws Exception {
		try {
			Allure.description("Mobile - Dial a number");
			String testCaseDetails = "<b>" + "==================== " + testCase + " - Dial a number"
					+ " ====================" + "</b>";
			log.info(testCaseDetails);
			extentTest.info(testCaseDetails);
			Allure.step(testCaseDetails);
			dialNumber.clickDialPadIcon();
			extentTest.info("Clicked on dialpad icon");
			Allure.step("Clicked on dialpad icon");
			Map<Integer, String> numberMap = new HashMap<>();
			numberMap.put(0, "zero");
			numberMap.put(1, "one");
			numberMap.put(2, "two");
			numberMap.put(3, "three");
			numberMap.put(4, "four");
			numberMap.put(5, "five");
			numberMap.put(6, "six");
			numberMap.put(7, "seven");
			numberMap.put(8, "eight");
			numberMap.put(9, "nine");

			String number = "512345678";
			log.info("Dial number : " + number);
			Allure.step("Dial number : " + number);
			Thread.sleep(10);
			for (int i = 0; i < number.length(); i++) {
				int num = Integer.valueOf(String.valueOf(number.charAt(i)));
				dialNumber.clickDialerIdBtn(numberMap.get(num));
				Allure.step("Dial number : " + numberMap.get(num));
			}
			extentTest.info("Dialed number: " + number);
			log.info("Dialed number : " + number);
			Allure.step("Dialed number : " + number);
			dialNumber.clickDialpadVoiceCallBtn();
			extentTest.info("Clicked on dialpad Voice Call Button");
			Allure.step("Clicked on dialpad Voice Call Button");
			Thread.sleep(15);
			if (dialNumber.incallEndCallBtnIsDisplayed()) {
				extentTest.pass("Your call was dialled successfuly",
						MediaEntityBuilder.createScreenCaptureFromPath(dialNumber.getScreenshotPath("No")).build());
				Allure.addAttachment("Dialpad", Files.newInputStream(Paths.get(dialNumber.getScreenshotPath("No"))));
				Allure.step("Test Passed", io.qameta.allure.model.Status.PASSED);
			} else {
				extentTest.fail("Your call was not dialled successfuly",
						MediaEntityBuilder.createScreenCaptureFromPath(dialNumber.getScreenshotPath("No")).build());
				Allure.addAttachment("Dialpad", Files.newInputStream(Paths.get(dialNumber.getScreenshotPath("No"))));
				Allure.step("Test Failed", io.qameta.allure.model.Status.FAILED);
			}
			dialNumber.clickIncallEndCallBtn();
			extentTest.info("Clicked on end call Button");
			Allure.step("Clicked on end call Button");
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}
	}

	@AfterMethod
	public void tearDown(Method m) throws Exception {
		log.info(m.getName() + " After method");
		try {
			if (driver != null) {
				driver.quit();
				extentTest.info("Driver quit");
				log.info(m.getName() + ": Driver: " + driverString + " quits successfully");
				Allure.step(m.getName() + ": Driver: " + driverString + " quits successfully");
			}
		} catch (Throwable t) {
			log.error(t.toString(), t);
			extentTest.fail(t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
		}
		log.info("====================" + m.getName() + " test ended" + "===================");
		Thread.sleep(4);
	}

	@AfterClass
	public void afterClassSetup() throws Exception {
		log.info("====================" + getClass().getName() + " execution ended" + "===================");
	}

}
