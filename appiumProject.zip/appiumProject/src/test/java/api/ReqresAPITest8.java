package api;

import static io.restassured.RestAssured.given;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import base.BaseTest;
import io.qameta.allure.Allure;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.testng.Tag;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ReqresAPITest8 extends BaseTest {

	final String baseURI = "https://reqres.in";
	final String basePath = "/api/users";
	Map<String, String> getCallQueryParamMap = new LinkedHashMap<>();

	@BeforeClass
	public void beforeClassSetup() throws Exception {
		log.info("==================== " + getClass().getName() + " Execution Started" + "==================== ");
	}

	@BeforeMethod
	public void getMethodName(Method m) {
		log.info("==================== " + m.getName() + " Execution Started" + "==================== ");
		Allure.step("Set up is successful");
	}

	@Epic("API - ReqRes - Get Call - Epic")
	@Feature("API - ReqRes - Get Call - Feature")
	@Story("API - ReqRes - Get Call - Story")
	@Tag("Smoke")
	@Severity(SeverityLevel.BLOCKER)
	@Step
	@Test(invocationCount = 1, groups = { "Smoke" })
	public void getCall() throws Exception {
		getCallHelper();
	}

	@Epic("API - ReqRes - Get Call2 - Epic")
	@Feature("API - ReqRes - Get Call2 - Feature")
	@Story("API - ReqRes - Get Call2 - Story")
	@Tag("Sanity")
	@Severity(SeverityLevel.CRITICAL)
	@Step
	@Test(invocationCount = 1, groups = { "Sanity" })
	public void getCall2() throws Exception {
		extentTest.assignCategory("Regression");
		getCallHelper();
	}

	@Epic("API - ReqRes - Get Call3 - Epic")
	@Feature("API - ReqRes - Get Call3 - Feature")
	@Story("API - ReqRes - Get Call3 - Story")
	@Tag("Regression")
	@Severity(SeverityLevel.MINOR)
	@Step
	@Test(invocationCount = 1, groups = { "Regression" })
	public void getCall3() throws Exception {
		extentTest.assignCategory("Regression");
		getCallHelper();
	}

	@Epic("API - ReqRes - Get Call4 - Epic")
	@Feature("API - ReqRes - Get Call4 - Feature")
	@Story("API - ReqRes - Get Call4 - Story")
	@Tag("SmokeSanity")
	@Severity(SeverityLevel.NORMAL)
	@Step
	@Test(invocationCount = 1, groups = { "Smoke", "Sanity" })
	public void getCall4() throws Exception {
		extentTest.assignCategory("Regression");
		getCallHelper();
	}

	@Epic("API - ReqRes - Get Call5 - Epic")
	@Feature("API - ReqRes - Get Call5 - Feature")
	@Story("API - ReqRes - Get Call5 - Story")
	@Tag("SmokeRegression")
	@Severity(SeverityLevel.TRIVIAL)
	@Step
	@Test(invocationCount = 1, groups = { "Smoke", "Regression" })
	public void getCall5() throws Exception {
		extentTest.assignCategory("Regression");
		getCallHelper();
	}

	@Epic("API - ReqRes - Post Call - Epic")
	@Feature("API - ReqRes - Post Call - Feature")
	@Story("API - ReqRes - Post Call - Story")
	@Tag("Smoke")
	@Severity(SeverityLevel.BLOCKER)
	@Step
	@Test(invocationCount = 1, groups = { "Smoke" })
	public void postCall() throws Exception {
		extentTest.assignCategory("Regression");
		postCallHelper();
	}

	@Epic("API - ReqRes - Post Call2 - Epic")
	@Feature("API - ReqRes - Post Call2 - Feature")
	@Story("API - ReqRes - Post Call2 - Story")
	@Tag("Sanity")
	@Severity(SeverityLevel.CRITICAL)
	@Step
	@Test(invocationCount = 1, groups = { "Sanity" })
	public void postCall2() throws Exception {
		extentTest.assignCategory("Regression");
		postCallHelper();
	}

	@Epic("API - ReqRes - Post Call3 - Epic")
	@Feature("API - ReqRes - Post Call3 - Feature")
	@Story("API - ReqRes - Post Call3 - Story")
	@Tag("Regression")
	@Severity(SeverityLevel.MINOR)
	@Step
	@Test(invocationCount = 1, groups = { "Regression" })
	public void postCall3() throws Exception {
		extentTest.assignCategory("Regression");
		postCallHelper();
	}

	@Epic("API - ReqRes - Post Call4 - Epic")
	@Feature("API - ReqRes - Post Call4 - Feature")
	@Story("API - ReqRes - Post Call4 - Story")
	@Tag("SmokeSanity")
	@Severity(SeverityLevel.NORMAL)
	@Step
	@Test(invocationCount = 1, groups = { "Smoke", "Sanity" })
	public void postCall4() throws Exception {
		extentTest.assignCategory("Regression");
		postCallHelper();
	}

	@Epic("API - ReqRes - Post Call5 - Epic")
	@Feature("API - ReqRes - Post Call5 - Feature")
	@Story("API - ReqRes - Post Call5 - Story")
	@Tag("SmokeRegression")
	@Severity(SeverityLevel.TRIVIAL)
	@Step
	@Test(invocationCount = 1, groups = { "Smoke", "Regression" })

	public void postCall5() throws Exception {
		extentTest.assignCategory("Regression");
		postCallHelper();
	}

	public void getCallHelper() throws Exception {
		try {
			extentTest = extentReports.createTest("API - ReqRes - Get Call", "API - ReqRes - Get Call");
			Allure.description("API - ReqRes - Get Call");

			// RequestSpecification
			// https://reqres.in/api/users?page=2
			getCallQueryParamMap.put("page", "2");
			RequestSpecification requestSpecification = given().baseUri(baseURI).basePath(basePath)
					.queryParam(getCallQueryParamMap.get("page"));
			log.info(requestSpecification);

			// Request details
			System.out.println("Request details:");
			requestSpecification.log().all();

			// Response
			Response getUserResonse = requestSpecification.when().get();

			System.out.println("\n" + "Response details:");
			getUserResonse.then().log().all();

			String requstURI = baseURI + basePath + getCallQueryParamMap.get("page");
			int responsestatusCode = getUserResonse.statusCode();
			String responsestatusLine = getUserResonse.getStatusLine();
			Headers responseHeaders = getUserResonse.getHeaders();
			String responseBody = getUserResonse.asPrettyString();
			long responseTime = getUserResonse.getTime();

			extentTest.log(Status.INFO, "Request URI: " + requstURI);
			log.info("Request URI: " + requstURI);
			Allure.step("Request URI: " + requstURI);
			extentTest.log(Status.INFO, "Response Statuscode: " + responsestatusCode);
			log.info("Response Statuscode: " + responsestatusCode);
			Allure.step("Response Statuscode: " + responsestatusCode);
			extentTest.log(Status.INFO, "Response StatusLine: " + responsestatusLine);
			log.info("Response StatusLine: " + responsestatusLine);
			Allure.step("Response StatusLine: " + responsestatusLine);
			extentTest.log(Status.INFO, "Response Headers: " + responseHeaders);
			log.info("Response Headers: " + responseHeaders);
			Allure.step("Response Headers: " + responseHeaders);
			extentTest.log(Status.INFO, "Response Body: " + responseBody);
			log.info("Response Body: " + responseBody);
			Allure.step("Response Body: " + responseBody);
			extentTest.log(Status.INFO, "Response time: " + responseTime);
			log.info("Response time: " + responseTime);
			Allure.step("Response time: " + responseTime);

			// Validation
			String[][] responseTable = { { "Statuscode", "StatusLine", "Response Time", "Response Body" },
					{ String.valueOf(responsestatusCode), responsestatusLine, String.valueOf(responseTime),
							responseBody } };
			if (responsestatusCode == 200) {
				int expectedPerPage = 6;
				log.info("expectedPerPage: " + expectedPerPage);
				Allure.step("expectedPerPage: " + expectedPerPage);
				int actualPerPage = Integer.valueOf(getUserResonse.jsonPath().getString("per_page"));
				log.info("ActualPerPage: " + actualPerPage);
				Allure.step("ActualPerPage: " + actualPerPage);
				int actualPerPageSize = getUserResonse.jsonPath().getList("data").size();
				log.info("actualPerPageSize: " + actualPerPageSize);
				Assert.assertEquals(actualPerPage, expectedPerPage);
				Assert.assertEquals(actualPerPageSize, expectedPerPage);
				extentTest.info("<b>Expected Result</b>");
				extentTest.log(Status.PASS, MarkupHelper.createTable(responseTable));
				log.info("Test Passed");
				Allure.step("Test Passed", io.qameta.allure.model.Status.PASSED);
			} else {
				extentTest.info("<b>Actual Result</b>");
				extentTest.log(Status.FAIL, MarkupHelper.createTable(responseTable));
				log.info("Test Failed");
				Allure.step("Test Failed", io.qameta.allure.model.Status.FAILED);
			}
		} catch (Throwable t) {
			extentTest.fail(t);
			log.error(t, t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}

	}

	public void postCallHelper() throws Exception {
		try {
			extentTest = extentReports.createTest("API - ReqRes - POST Call", "API - ReqRes - POST Call");
			Allure.description("API - ReqRes - Post Call");

			// RequestSpecification
			// https://reqres.in/api/users
			// Request body
			Map postRequestBody = new LinkedHashMap<>();
			postRequestBody.put("name", "morpheus");
			postRequestBody.put("job", "leader");
			RequestSpecification requestSpecification = given().baseUri(baseURI).basePath(basePath)
					.contentType(ContentType.JSON).body(postRequestBody);
			log.info(requestSpecification);

			// Request details
			System.out.println("Request details:");
			requestSpecification.log().all();

			// Response
			Response postUserResonse = requestSpecification.when().post();

			System.out.println("\n" + "Response details:");
			postUserResonse.then().log().all();

			String requstURI = baseURI + basePath;
			String requstbody = postRequestBody.toString();
			int responsestatusCode = postUserResonse.statusCode();
			String responsestatusLine = postUserResonse.getStatusLine();
			Headers responseHeaders = postUserResonse.getHeaders();
			String responseBody = postUserResonse.asPrettyString();
			long responseTime = postUserResonse.getTime();

			extentTest.log(Status.INFO, "Request URI: " + requstURI);
			log.info("Request URI: " + requstURI);
			Allure.step("Request URI: " + requstURI);
			extentTest.log(Status.INFO, "Request body: " + requstbody);
			log.info("Request body: " + requstbody);
			Allure.step("Request body: " + requstbody);
			extentTest.log(Status.INFO, "Response Statuscode: " + responsestatusCode);
			log.info("Response Statuscode: " + responsestatusCode);
			Allure.step("Response Statuscode: " + responsestatusCode);
			extentTest.log(Status.INFO, "Response StatusLine: " + responsestatusLine);
			log.info("Response StatusLine: " + responsestatusLine);
			Allure.step("Response StatusLine: " + responsestatusLine);
			extentTest.log(Status.INFO, "Response Headers: " + responseHeaders);
			log.info("Response Headers: " + responseHeaders);
			Allure.step("Response Headers: " + responseHeaders);
			extentTest.log(Status.INFO, "Response Body: " + responseBody);
			log.info("Response Body: " + responseBody);
			Allure.step("Response Body: " + responseBody);
			extentTest.log(Status.INFO, "Response time: " + responseTime);
			log.info("Response time: " + responseTime);
			Allure.step("Response time: " + responseTime);

			// Validation
			String[][] responseTable = { { "Statuscode", "StatusLine", "Response Time", "Response Body" },
					{ String.valueOf(responsestatusCode), responsestatusLine, String.valueOf(responseTime),
							responseBody } };
			int exectedStatusCode = 201;
			if (responsestatusCode == exectedStatusCode) {
				extentTest.info("<b>Expected Result</b>");
				extentTest.log(Status.PASS, MarkupHelper.createTable(responseTable));
				log.info("Test Passed");
				Allure.step("Actual response status code: " + responsestatusCode);
				Allure.step("Expected response status code: " + exectedStatusCode);
				Allure.step("Test Passed", io.qameta.allure.model.Status.PASSED);
			} else {
				extentTest.info("<b>Actual Result</b>");
				extentTest.log(Status.FAIL, MarkupHelper.createTable(responseTable));
				log.info("Test Failed");
				Allure.step("Actual response status code: " + responsestatusCode);
				Allure.step("Expected response status code: " + exectedStatusCode);
				Allure.step("Test Passed", io.qameta.allure.model.Status.FAILED);
			}
		} catch (Throwable t) {
			extentTest.fail(t);
			log.error(t, t);
			Allure.step(t.toString(), io.qameta.allure.model.Status.FAILED);
			throw new Exception(t);
		}

	}

	@AfterMethod
	public void tearDown(Method m) {
		log.info("==================== " + m.getName() + " Execution Ended" + "==================== ");
		Allure.step("Tear down is successful");
	}

	@AfterClass
	public void afterClassSetup() throws Exception {
		log.info("==================== " + getClass().getName() + " Execution Ended" + "==================== ");
	}

}
