package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.web.WebBasePage;

public class ProfessionalServicesPage extends WebBasePage {

	public ProfessionalServicesPage(WebDriver driver) {
		super(driver, pagelogs);
	}

	String worldClassAutomatedTesting = "//*[@id=\"post-217558\"]/div/div[1]/div/div[1]/section/div[1]/div/div/h1";
	String unparalledTestAutomation = "//*[@id=\"post-217558\"]/div/div[1]/div/div[1]/section/div[1]/div/div/div/p/span";
	String getFreeConsulation = "//*[@id=\"post-217558\"]/div/div[1]/div/div[1]/section/div[1]/div/div/a";

	public By byWorldClassAutomatedTesting = By.xpath(worldClassAutomatedTesting);
	public By byUnparalledTestAutomation = By.xpath(unparalledTestAutomation);
	public By byGetFreeConsulation = By.xpath(getFreeConsulation);

	public String getPageTitle() {
		return getTitle();
	}

	public String worldClassAutomatedTestingText() {
		return readText(byWorldClassAutomatedTesting);
	}

	public String unparalledTestAutomationText() {
		return readText(byUnparalledTestAutomation);
	}

	public void clickGetFreeConsulationButton() {
		presenceOfElementLocatedwait(byGetFreeConsulation).click();
//		click(byGetFreeConsulation);
	}

}
