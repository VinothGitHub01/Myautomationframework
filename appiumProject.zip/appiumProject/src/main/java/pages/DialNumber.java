package pages;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;

public class DialNumber extends BasePage {

	public DialNumber(AppiumDriver<WebElement> driver) {
		super(driver);
	}

	String dialpadTab = "com.google.android.dialer:id/dialpad_fab";
	String dialerId = "com.google.android.dialer:id/";
	String dialpadVoiceCallButton = "com.google.android.dialer:id/dialpad_voice_call_button";
	String incallEndCall = "com.google.android.dialer:id/incall_end_call";

	@Override
	public String toString() {
		return "DialNumber [dialpadTab=" + dialpadTab + ", dialerId=" + dialerId + ", dialpadVoiceCallButton="
				+ dialpadVoiceCallButton + ", incallEndCall=" + incallEndCall + "]";
	}

	public void clickDialPadIcon() {
		click("id", dialpadTab, "Yes");
	}

	public void clickDialerIdBtn(String numberString) {
		click("id", dialerId + numberString, "Yes");
	}

	public void clickDialpadVoiceCallBtn() {
		click("id", dialpadVoiceCallButton, "Yes");
	}

	public void clickIncallEndCallBtn() {
		click("id", incallEndCall, "Yes");
	}

	public boolean incallEndCallBtnIsDisplayed() {
		return isDisplayed(incallEndCall, "Yes");
	}

}
