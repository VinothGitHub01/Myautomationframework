package pages.web;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebBasePage {

	public WebDriver driver;
	public static String screenshotPath = System.getProperty("user.dir") + "/Screenshots/";
	public static Logger pagelogs;

	public WebBasePage(WebDriver driver, Logger log) {
		this.driver = driver;
		WebBasePage.pagelogs = LogManager.getLogger(getClass());
	}

	public String getTitle() {
		String title = driver.getTitle();
		pagelogs.info(getClass().getSimpleName() + ": title: " + title);
		return title;
	}

	public String readText(By by) {
		presenceOfElementLocatedwait(by);
		pagelogs.info(getClass().getSimpleName() + ": readText: " + by.toString());
		String text = driver.findElement(by).getText();
		return text;
	}

	public void sendKeys(By by, String text) {
		presenceOfElementLocatedwait(by);
		pagelogs.info(getClass().getSimpleName() + ": click: " + by.toString());
		driver.findElement(by).sendKeys(text);
	}

	public void click(By by) {
		presenceOfElementLocatedwait(by);
		pagelogs.info(getClass().getSimpleName() + ": click: " + by.toString());
		driver.findElement(by).click();
	}

	public boolean isElementDisplayed(By by) {
		presenceOfElementLocatedwait(by);
		pagelogs.info(getClass().getSimpleName() + ": isElementDisplayed: " + by.toString());
		boolean isElementDisplayed = driver.findElement(by).isDisplayed();
		return isElementDisplayed;
	}

	public boolean isElementEnabled(By by) {
		presenceOfElementLocatedwait(by);
		pagelogs.info(getClass().getSimpleName() + ": isElementEnabled: " + by.toString());
		return driver.findElement(by).isEnabled();
	}

	public void clearContent(By by) {
		presenceOfElementLocatedwait(by);
		pagelogs.info(getClass().getSimpleName() + ": isElementDisplayed: " + by.toString());
		driver.findElement(by).clear();
	}

	public WebElement presenceOfElementLocatedwait(By by) {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebDriverWait wait = new WebDriverWait(driver, 30);
		pagelogs.info(getClass().getSimpleName() + ": wait for: " + by.toString());
		return wait.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public String takeScreenshots(String base64) throws IOException {
		String destPath = "";
		if ((base64.equals("base64"))) {
			destPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
		} else if (base64.equals("Yes")) {
			destPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
		} else if (base64.equals("YES")) {
			destPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
		} else {
			File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File destFile = new File(screenshotPath
					+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY_mm_dd_HH_MM_SS")) + ".png");
			FileUtils.copyFile(srcFile, destFile);
			destPath = destFile.getAbsolutePath();
		}
		return destPath;
	}

}
