package pages.web;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends WebBasePage {

	public HomePage(WebDriver driver) {
		super(driver, pagelogs);
	}

	String ultiMateQAIMG = "//div[@class='et_pb_menu__logo']";
	String javaSDETAcademyLink = "//a[text()='Java SDET Academy']";

	public By byUltiMateQAIMG = By.xpath(ultiMateQAIMG);
	public By byJavaSDETAcademyLink = By.xpath(javaSDETAcademyLink);

	public String getPageTitle() {
		return getTitle();
	}

	public boolean ultiMateQAIMGIsExit() {
		return isElementDisplayed(byUltiMateQAIMG);
	}

	public void clickJavaSDETAcademyLink() {
		click(byJavaSDETAcademyLink);
	}

	public String javaSDETAcademyLinkText() {
		return readText(byJavaSDETAcademyLink);
	}

}
