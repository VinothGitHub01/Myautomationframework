package pages;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseTest;
import io.appium.java_client.AppiumDriver;

public class BasePage {

	public AppiumDriver<WebElement> driver;
	public static Logger log;

	public BasePage(AppiumDriver<WebElement> driver) {
		this.driver = driver;
//		log = LogManager.getLogger(getClass());
		log = LogManager.getLogger();
	}

	public void click(String locatorType, String locator, String applyExplicitWait) {
		switch (locatorType) {
		case "id":
			if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
					&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
				explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byId(locator))).click();
				log.info("Click - " + byId(locator));
			} else {
				driver.findElementById(locator).click();
				log.info("Click - " + byId(locator));
			}
			break;
		case "xpath":
			if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
					&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
				explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byXpath(locator))).click();
				log.info("Click - " + byXpath(locator));
			} else {
				driver.findElementById(locator).click();
				log.info("Click - " + byXpath(locator));
			}
			break;
		}
	}

	public void sendKeys(String locatorType, String locator, String text, String applyExplicitWait) {
		switch (locatorType) {
		case "id":
			if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
					&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
				explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byId(locator))).sendKeys(text);
				log.info("Sendkeys - " + byId(text));
			} else {
				driver.findElementById(locator).sendKeys(text);
				log.info("Sendkeys - " + byId(locator));
			}
			break;
		case "xpath":
			if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
					&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
				explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byXpath(locator))).sendKeys(text);
				log.info("Sendkeys - " + byXpath(locator));
			} else {
				driver.findElementById(locator).sendKeys(text);
				log.info("Sendkeys - " + byXpath(locator));
			}
			break;
		}
	}

	public String getText(String locatorType, String locator, String applyExplicitWait) {
		String getText = "";
		switch (locatorType) {
		case "id":
			if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
					&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
				getText = explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byId(locator))).getText();
				log.info("Get Text - " + byId(locator));
			} else {
				getText = driver.findElementById(locator).getText();
				log.info("Get Text - " + byId(locator));
			}
			break;
		case "xpath":
			if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
					&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
				getText = explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byXpath(locator)))
						.getText();
				log.info("Get Text - " + byXpath(locator));
			} else {
				getText = driver.findElementByXPath(locator).getText();
				log.info("Get Text - " + byXpath(locator));
			}
			break;
		}
		return getText;
	}

	public boolean isDisplayed(String id, String applyExplicitWait) {
		boolean isDisplayed = false;
		if ((applyExplicitWait != null) && (!applyExplicitWait.isEmpty()) && (!applyExplicitWait.isBlank())
				&& (applyExplicitWait.equalsIgnoreCase("Yes"))) {
			isDisplayed = explicitWait().until(ExpectedConditions.visibilityOfElementLocated(byId(id))).isDisplayed();
			log.info("Element is displayed - " + byId(id));
		} else {
			isDisplayed = driver.findElementById(id).isDisplayed();
			log.info("Element is displayed - " + byId(id));
		}
		return isDisplayed;

	}

	public static By byId(String id) {
		return By.id(id);
	}

	public static By byXpath(String xPath) {
		return By.xpath(xPath);
	}

	public String getScreenshotPath(String usingBase64) throws IOException {
		String screenshotPath = null;
		switch (usingBase64) {
		case "usingBase64":
			screenshotPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			break;
		case "Yes":
			screenshotPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			break;
		case "YES":
			screenshotPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			break;
		default:
			File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File destFile = new File(System.getProperty("user.dir") + "/Screenshots/"
					+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY_mm_dd_HH_MM_SS")) + ".png");
			FileUtils.copyFile(srcFile, destFile);
			screenshotPath = destFile.getAbsolutePath();
			break;
		}
		return screenshotPath;
	}

	public WebDriverWait explicitWait() {
		WebDriverWait expWait = new WebDriverWait(driver, 50);
		return expWait;
	}

}
