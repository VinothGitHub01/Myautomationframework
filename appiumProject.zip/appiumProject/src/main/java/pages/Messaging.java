package pages;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;

public class Messaging extends BasePage {

	public Messaging(AppiumDriver<WebElement> driver) {
		super(driver);
	}

	String messagesButton = "//android.widget.TextView[@content-desc=\"Messages\"]";
	String welcomeText = "com.google.android.apps.messaging:id/empty_text_hint";
	String startChatTab = "com.google.android.apps.messaging:id/start_chat_fab";
	String recipientTextView = "com.google.android.apps.messaging:id/recipient_text_view";
	String contactName = "com.google.android.apps.messaging:id/contact_name";
	String composeMessageText = "com.google.android.apps.messaging:id/compose_message_text";
	String sendMessageButton = "com.google.android.apps.messaging:id/send_message_button_icon";
	String messageStatus = "com.google.android.apps.messaging:id/message_status";
	String backButton = "//android.widget.ImageButton[@content-desc=\"Navigate up\"]";

	public void clickMessagesButton() {
		click("xpath", messagesButton, "Yes");
	}

	public String getWelcomeText() {
		return getText("id", welcomeText, "Yes");
	}

	public void clickStartChatTab() {
		click("id", startChatTab, "Yes");
	}

	public void sendRecipientText(String text) {
		sendKeys("id", recipientTextView, text, "Yes");
	}

	public boolean recipientTextViewIsDisplayed() {
		return isDisplayed(recipientTextView, "Yes");
	}

	public String getContactName() {
		return getText("id", contactName, "No");
	}

	public void clickContactName() {
		click("id", contactName, "No");
	}

	public void sendcomposeMessageText(String text) {
		sendKeys("id", composeMessageText, text, "Yes");
	}

	public void clickSendMessageButton() {
		click("id", sendMessageButton, "Yes");
	}

	public boolean messageStatusIsDisplayed() {
		return isDisplayed(messageStatus, "Yes");
	}

	public void clickBackButton() {
		click("xpath", backButton, "Yes");
	}

}
