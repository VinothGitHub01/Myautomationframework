package utils;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.safari.SafariDriver;

import base.BaseTest;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Utilities {

	public static void main(String[] args) {

		System.out.println(LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY_mm_dd_HH_MM_SS")));
		System.out.println(LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY_MM_dd_HH_MM_SS")));

		System.out.println(testCaseParser("TC01-TC25"));

		try {
			System.out.println("getIPAddress(): " + getIPAddress());
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}

		try {
			InetAddress ip = InetAddress.getLocalHost();
			System.out.println("ip: " + ip.toString());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		clearFilesFromFolder(System.getProperty("user.dir") + "/Logs");
		clearFilesFromFolder(System.getProperty("user.dir") + "/Reports");
		clearFilesFromFolder(System.getProperty("user.dir") + "/Screenshots");

	}

	public static String formatDate(String format) {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern(format));
	}

	public static void clearFilesFromFolder(String folderPath) {
		File file = new File(folderPath);
		for (File folderFile : file.listFiles()) {
			folderFile.delete();
		}
		System.out.println("Files are deleted successfully");

	}

	public static String getIPAddress() throws UnknownHostException {
		InetAddress ip = InetAddress.getLocalHost();
		String[] ipSplitArray = ip.toString().split("/");
		return ipSplitArray[1].toString().trim();
	}

	public static LinkedHashMap<String, String> testCaseParser(String testCase) {
		LinkedHashMap<String, String> testCases = new LinkedHashMap<>();
		if (testCase.startsWith("TC") || testCase.startsWith("tc")) {
			if (testCase.contains("-")) {
				String[] testCaseArray = testCase.split("-");
				String startingTc = testCaseArray[0];
				String endingTc = testCaseArray[1];
				String remaingTc = null;
				if (endingTc.length() > 0) {
					int startingTcNum = Integer.valueOf(startingTc.substring(2));
					int endingTcNum = Integer.valueOf(endingTc.substring(2));
					while (startingTcNum <= endingTcNum) {
						if (startingTcNum < 10) {
							remaingTc = startingTc.substring(0, 2) + "0" + startingTcNum;
						} else {
							remaingTc = startingTc.substring(0, 2) + startingTcNum;
						}
						testCases.put(remaingTc, remaingTc);
						startingTcNum++;
					}
				}
			} else {
				testCases.put(testCase, testCase);
			}
		}
		return testCases;
	}

	public static void openCustomizedExtentReport(String reportPath) {
		WebDriver seleniumDriver = null;
		try {
			Thread.sleep(10);
			WebDriverManager.safaridriver().setup();
			seleniumDriver = new SafariDriver();
			BaseTest.log.info("seleniumDriver - " + seleniumDriver);
			// /Users/vinoth.shanmugam/eclipse-workspace/appiumProject/Reports/Automationreport_2023_11_08_16_11_30
			seleniumDriver.get("file://" + reportPath + ".html#");
			BaseTest.log.info("seleniumDriver - Launched " + "file://" + reportPath + ".html#" + " successfully");
			Thread.sleep(25);
			seleniumDriver.manage().window().maximize();
			seleniumDriver.findElement(By.xpath("//a[@id='nav-dashboard']/span")).click();
			BaseTest.log.info("Clicked report dashboard");
			Thread.sleep(10);
			JavascriptExecutor js = ((JavascriptExecutor) seleniumDriver);
			WebElement testGraphEle = seleniumDriver.findElement(By.xpath("//div/div/canvas[@id='parent-analysis']"));
			BaseTest.log.info("Report - parent-analysis graph resized sucessfully");
			js.executeAsyncScript("arguments[0].setAttribute('style', 'display: block; height: 390px; width: 503px;')",
					testGraphEle);
		} catch (Throwable t) {
		} finally {
			try {
				JavascriptExecutor js = ((JavascriptExecutor) seleniumDriver);
				WebElement eventGraphEle = seleniumDriver
						.findElement(By.xpath("//div/div/canvas[@id='events-analysis']"));
				BaseTest.log.info("Report - events-analysis graph resized sucessfully");
				js.executeAsyncScript(
						"arguments[0].setAttribute('style', 'display: block; height: 390px; width: 503px;')",
						eventGraphEle);
			} catch (Throwable t) {
			}
		}
	}

	public static void openAllureReport(String allureURL) {
		WebDriver seleniumDriver = null;
		try {
			Thread.sleep(10);
			WebDriverManager.safaridriver().setup();
			seleniumDriver = new SafariDriver();
			BaseTest.log.info("seleniumDriver - " + seleniumDriver);
			// http://192.168.90.115:55777/index.html
			seleniumDriver.get(allureURL);
			BaseTest.log.info("seleniumDriver - Launched " + allureURL + " successfully");
			Thread.sleep(25);
			seleniumDriver.manage().window().maximize();
		} catch (Throwable t) {
			BaseTest.log.error(t);
		}
	}

}
