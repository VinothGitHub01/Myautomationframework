package listeners;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry implements IRetryAnalyzer {

	int testCounter = 0;
	int retryCount = 1;

	@Override
	public boolean retry(ITestResult result) {
		if (testCounter < retryCount) {
			testCounter++;
			return true;
		}
		return false;
	}

}
