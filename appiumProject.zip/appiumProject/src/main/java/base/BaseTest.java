package base;

import java.net.URL;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.Utilities;

public class BaseTest {

	public static ExtentReports extentReports;
	public static ExtentSparkReporter extentSparkReporter;
	protected static AppiumDriver<WebElement> driver;
	public static WebDriver webDriver;
	public ExtentTest extentTest;
	public static DesiredCapabilities dc;
	public static Logger log;
	public static String reportPath;

	@BeforeSuite
	public void suiteSetUp() {
//		log = LogManager.getLogger(getClass());
		log = LogManager.getLogger();
		log.info(
				"====================================  Automation Execution Started ==================================== ");
		extentReports = new ExtentReports();
		reportPath = System.getProperty("user.dir") + "/Reports/" + "Automationreport_"
				+ Utilities.formatDate("YYYY_MM_dd_HH_MM_SS");
		extentReports.setSystemInfo("Username", System.getProperty("user.name"));
		extentSparkReporter = new ExtentSparkReporter(reportPath);
		extentSparkReporter.config().setReportName("<center>" + "Automation Test Results" + "</center>");
		extentSparkReporter.config().setTheme(Theme.DARK);
		extentSparkReporter.config().setJs(
				"document.getElementsByClassName('col-sm-12 col-md-4')[0].style.setProperty('min-inline-size','-webkit-fill-available');");
		extentReports.attachReporter(extentSparkReporter);
	}

	// Mobile Driver
	public static AppiumDriver<WebElement> setUpDriver(String platform, URL url, DesiredCapabilities dc) {
		switch (platform) {
		case "Android":
			driver = new AndroidDriver<>(url, dc);
			break;
		case "IOS":
			driver = new IOSDriver<>(url, dc);
			break;
		default:
			driver = new AppiumDriver<>(url, dc);
			break;
		}

		log.info("driver setup is successful: " + driver);
		return driver;
	}

	// Web Driver
	public static WebDriver iniaiteWebDriver(String browser) {
		browser = browser.toLowerCase();
		switch (browser) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			webDriver = new ChromeDriver();
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			webDriver = new FirefoxDriver();
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			webDriver = new EdgeDriver();
			break;
		case "safari":
			WebDriverManager.safaridriver().setup();
			webDriver = new SafariDriver();
			break;
		default:
			webDriver = new ChromeDriver();
			break;
		}

		webDriver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		return webDriver;
	}

	public void web_OpenURL(String url) throws InterruptedException {
		webDriver.get(url);
		Thread.sleep(30);
	}

	public static DesiredCapabilities setUpDesiredCapababilties(LinkedHashMap<String, String> desiredCapabilities) {
		Iterator<String> keySetItr = desiredCapabilities.keySet().iterator();
		dc = new DesiredCapabilities();
		while (keySetItr.hasNext()) {
			String key = keySetItr.next().toString();
			dc.setCapability(key, desiredCapabilities.get(key));
		}
		log.info("Desired Capabalities setup is successful: " + dc);
		return dc;
	}

	@AfterTest
	public void baseBeforeTest() throws InterruptedException {
		Thread.sleep(15);
		log.info("After base test");
	}

	@AfterSuite
	public void suiteTearDown() throws InterruptedException {
		Thread.sleep(10);
		extentReports.flush();
		log.info("Extent reports flushed successfully");
		log.info("Extent Report path: " + reportPath);
		Utilities.openCustomizedExtentReport(reportPath);
		log.info(
				"====================================  Automation Execution Ended ==================================== ");
	}

}
